Stop-Process -Id 6984 -Force
Stop-Process -Id 21676 -Force