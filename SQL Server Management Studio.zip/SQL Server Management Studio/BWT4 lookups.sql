select * from EDI856_SHIPMENT es where shipment_id in ('bw925190080','bw923569122', 'bw923764406', 'bw924028899', 'bw924168257', 'bw924830028', 'bw924934121', 'bw925054911', 'bw925483731', 'bw925542163') order by DATETIME_SENT desc


select * from EDI856_ORDER eo where eo.shipment_id in ('bw923569122', 'bw923764406', 'bw924028899', 'bw924168257', 'bw924830028', 'bw924934121', 'bw925054911', 'bw925483731', 'bw925542163')