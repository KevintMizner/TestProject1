--Select * from AD_Analysis.[NovaStaging].[Carrier]
--select top 10  * from ASCTrac6.[dbo].[ORDRHDR] where SOLDTOCUSTID like '%GMI%' order by requiredshipdate desc
--select top 10  * from ASCTrac6.[dbo].[POHDR] where VENDORID like '%GMI%' order by orderdate desc

--select top 10  * from ASCTrac6.[dbo].[ORDRHDR] where ORDERNUMBER ='2098975316'



ALTER PROCEDURE API_OPENDOC_TEST

    @refNumbers NVARCHAR(MAX),
    @Result INT OUTPUT,
    @Message NVARCHAR(MAX) OUTPUT,
    @InsertedID INT OUTPUT
AS
BEGIN
    /*
    Author: [Your Name]
    Version: 1.0
    Date: [Current Date]
    Description: This stored procedure validates a list of order or PO numbers and returns the validation result.
    */

    -- Initialize variables
    DECLARE @foundRecordsCustPONum INT;
    DECLARE @notFoundValues TABLE (value NVARCHAR(MAX));
    DECLARE @notFoundValue NVARCHAR(MAX) = NULL;

    -- Check for empty input
    IF LEN(@refNumbers) = 0
    BEGIN
        SET @Result = 0;
        SET @Message = 'Input list is empty.';
        SET @InsertedID = NULL;
        SELECT @Result AS Result, @Message AS Message, @InsertedID AS LogEntryID;
        RETURN;
    END

    -- Split the input list
    CREATE TABLE #TempRefNumbers (value NVARCHAR(MAX));
    INSERT INTO #TempRefNumbers (value)
    SELECT value FROM STRING_SPLIT(@refNumbers, ',');

    -- Count the total number of values
    DECLARE @totalValues INT = (SELECT COUNT(*) FROM #TempRefNumbers);

    -- Check if any value is found in CUSTPONUM column
    SELECT @foundRecordsCustPONum = COUNT(*)
    FROM ASCTrac6.[dbo].[ORDRHDR] o
    INNER JOIN #TempRefNumbers t ON o.CUSTPONUM = t.value;

    -- If any value is found in CUSTPONUM, all values must be found
    IF @foundRecordsCustPONum > 0
    BEGIN
        IF @foundRecordsCustPONum <> @totalValues
        BEGIN
            INSERT INTO @notFoundValues (value)
            SELECT t.value
            FROM #TempRefNumbers t
            LEFT JOIN ASCTrac6.[dbo].[ORDRHDR] o ON o.CUSTPONUM = t.value
            WHERE o.CUSTPONUM IS NULL;

            SELECT TOP 1 @notFoundValue = value FROM @notFoundValues;

            SET @Result = 0;
            SET @Message = 'These appear to be PO Numbers but not all were found. First failed order number: ' + @notFoundValue;
            SET @InsertedID = NULL;
            SELECT @Result AS Result, @Message AS Message, @InsertedID AS LogEntryID;
            DROP TABLE #TempRefNumbers;
            RETURN;
        END
        ELSE
        BEGIN
            SET @Message = 'Validation successful. All values found in CUSTPONUM.';
            SET @Result = 1;
            SET @InsertedID = NULL;
            SELECT @Result AS Result, @Message AS Message, @InsertedID AS LogEntryID;
            DROP TABLE #TempRefNumbers;
            RETURN;
        END
    END
    ELSE
    BEGIN
        -- No values found in CUSTPONUM, proceed to check ORDERNUMBER field
        SELECT @foundRecordsCustPONum = COUNT(*)
        FROM ASCTrac6.[dbo].[ORDRHDR] o
        INNER JOIN #TempRefNumbers t ON o.ORDERNUMBER = t.value;

        -- If not all values are found in ORDERNUMBER, fail
        IF @foundRecordsCustPONum <> @totalValues
        BEGIN
            INSERT INTO @notFoundValues (value)
            SELECT t.value
            FROM #TempRefNumbers t
            LEFT JOIN ASCTrac6.[dbo].[ORDRHDR] o ON o.ORDERNUMBER = t.value
            WHERE o.ORDERNUMBER IS NULL;

            SELECT TOP 1 @notFoundValue = value FROM @notFoundValues;

            SET @Result = 0;
            SET @Message = 'These appear to be Order Numbers but not all were found. First failed order number: ' + @notFoundValue;
            SET @InsertedID = NULL;
            SELECT @Result AS Result, @Message AS Message, @InsertedID AS LogEntryID;
            DROP TABLE #TempRefNumbers;
            RETURN;
        END
        ELSE
        BEGIN
            SET @Message = 'Validation successful. All values found in ORDERNUMBER.';
            SET @Result = 1;
            SET @InsertedID = NULL;
            SELECT @Result AS Result, @Message AS Message, @InsertedID AS LogEntryID;
            DROP TABLE #TempRefNumbers;
            RETURN;
        END
    END

    -- If all checks passed, continue with the next stage
    -- Your additional logic here

    -- If all submitted values are found, include them in the Message
    IF NOT EXISTS (SELECT 1 FROM @notFoundValues)
    BEGIN
        SET @Message = 'Validation successful. All orders found: ' + STUFF((SELECT ',' + value FROM #TempRefNumbers FOR XML PATH('')), 1, 1, '');
    END
    ELSE
    BEGIN
        SET @Result = 0;
        SET @Message = 'No records matching the values submitted were found.';
        SET @InsertedID = NULL;
        SELECT @Result AS Result, @Message AS Message, @InsertedID AS LogEntryID;
        DROP TABLE #TempRefNumbers;
        RETURN;
    END
END
