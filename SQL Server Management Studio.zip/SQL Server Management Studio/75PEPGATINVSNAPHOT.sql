SELECT 
    LOCITEMS.ITEMID, [SKIDID],
    CONVERT(INT, CONVERT(FLOAT, SUM(LOCITEMS.QTYTOTAL))) QTYTOTAL,
    CONVERT(DEC(20, 2), 
    CONVERT(FLOAT, SUM(LOCITEMS.QTYTOTAL * item.BOL_UNITWEIGHT))) WEIGHTTOTAL, 
    LOCITEMS.LOTID, 
    CONVERT(VARCHAR, LOCITEMS.EXPDATE, 112) AS EXPDATE, 
    case
      when qahold = 'T' then 'QH'
    else '33'
    end as Hold, 
    item.description, 
    item.STOCK_UOM, 
    CONVERT(VARCHAR, LOCITEMS.FRESHNESS_DATE, 112) AS FRESHNESS_DATE, 
    locitems.ALT_LOTID, 
    locitems.VMI_CUSTID,
	locitems.LOCATIONID



FROM LOCITEMS locitems 
join itemmstr item 
    on locitems.ASCITEMID = item.ASCITEMID
WHERE 
    LOCITEMS.VMI_CUSTID = '75pepgat' 
	-- Enter the vmi_custid for the client
GROUP BY 
    locitems.ITEMID, 
    locitems.ALT_LOTID, 
    LOTID, 
    EXPDATE, 
    qahold, 
    item.DESCRIPTION, 
    item.STOCK_UOM, 
    FRESHNESS_DATE, 
    locitems.VMI_CUSTID,
	locitems.LOCATIONID,
	locitems.[SKIDID]
