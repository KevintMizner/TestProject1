SELECT TOP (1000) [transaction_id]
      ,[process_flag]
      ,[partnerId]
      ,[TransdateTime]
      ,[environment]
      ,[warehouseId]
      ,[itemNumber]
      ,[itemDescription]
      ,[upc]
      ,[freightClass]
      ,[nmfcCode]
      ,[maxHeight]
      ,[palletType]
      ,[receivingOrderingUom]
      ,[rotationFormat]
      ,[shelfLife]
      ,[lotFormat]
      ,[lotSample]
      ,[productionExpiration]
      ,[unitsCase]
      ,[unitsPallet]
      ,[palletConfiguration1]
      ,[palletConfiguration2]
      ,[unitLength]
      ,[unitWidth]
      ,[unitHeight]
      ,[palletLength]
      ,[palletWidth]
      ,[palletHeight]
      ,[netWeight]
      ,[grossWeight]
      ,[palletWeight]
      ,[abcCode]
      ,[tariffCode]
      ,[countryOfOrigin]
  FROM [ASCTracEDI856].[dbo].[TBL_API_888_BW]
    where TransdateTime > '2024-04-22T19:28:05.813Z' 
	and itemnumber = 'CEHD1205433HCF'
  order by TransdateTime desc



  SELECT 
    itemnumber AS partnumber,
    COUNT(*) AS numberofoccurrences,
    MAX(TransdateTime) AS lastoccurrencedatetime
FROM 
    [ASCTracEDI856].[dbo].[TBL_API_888_BW]
WHERE 
    TransdateTime > '2024-04-22T19:28:05.813Z' 
    AND itemnumber IN (
        'CEHD1203033GCF', 'CEHD1203033JCF', 'CEHD1203633CCF-833', 
        'CEHD1203633GCF', 'CEHD1203633GCF-511', 'CEHD1203633LCF-866', 
        'CEHD1204533CCF-866', 'CEHD1205433GCF', 'CEHD1205433HCF', 
        'CEHD1205433LCF', 'CEHD1206', 'CEHD120A1533HCF', 'CEHD120A1553HCF', 
        'CEHD120A1553LCF', 'CEHD120A1833JCF-866', 'CEHD120A2433FCF', 
        'CEHD120A2733LCF', 'CEHD120A5431ECF', 'CEHD120A933JCF-866', 
        'CEHD5012333HCF', 'CEHD501233CCF-866', 'CEHD5013531ECF', 
        'CEHD5013533CCF', 'CEHD5013533LCF', 'CEHD5013533LCF-865', 
        'CEHD501833CCF-866', 'CEHD502731ECF'
    )
GROUP BY 
    itemnumber
ORDER BY 
    numberofoccurrences DESC;



	WITH PartNumbers AS (
    SELECT 'CEHD1203033GCF' AS partnumber UNION ALL
    SELECT 'CEHD1203033JCF' UNION ALL
    SELECT 'CEHD1203633CCF-833' UNION ALL
    SELECT 'CEHD1203633GCF' UNION ALL
    SELECT 'CEHD1203633GCF-511' UNION ALL
    SELECT 'CEHD1203633LCF-866' UNION ALL
    SELECT 'CEHD1204533CCF-866' UNION ALL
    SELECT 'CEHD1205433GCF' UNION ALL
    SELECT 'CEHD1205433HCF' UNION ALL
    SELECT 'CEHD1205433LCF' UNION ALL
    SELECT 'CEHD1206' UNION ALL
    SELECT 'CEHD120A1533HCF' UNION ALL
    SELECT 'CEHD120A1553HCF' UNION ALL
    SELECT 'CEHD120A1553LCF' UNION ALL
    SELECT 'CEHD120A1833JCF-866' UNION ALL
    SELECT 'CEHD120A2433FCF' UNION ALL
    SELECT 'CEHD120A2733LCF' UNION ALL
    SELECT 'CEHD120A5431ECF' UNION ALL
    SELECT 'CEHD120A933JCF-866' UNION ALL
    SELECT 'CEHD5012333HCF' UNION ALL
    SELECT 'CEHD501233CCF-866' UNION ALL
    SELECT 'CEHD5013531ECF' UNION ALL
    SELECT 'CEHD5013533CCF' UNION ALL
    SELECT 'CEHD5013533LCF' UNION ALL
    SELECT 'CEHD5013533LCF-865' UNION ALL
    SELECT 'CEHD501833CCF-866' UNION ALL
    SELECT 'CEHD502731ECF'
)

SELECT 
    PN.partnumber,
    COALESCE(COUNT(T.itemnumber), 0) AS numberofoccurrences,
    MAX(T.TransdateTime) AS lastoccurrencedatetime
FROM 
    PartNumbers PN
LEFT JOIN 
    [ASCTracEDI856].[dbo].[TBL_API_888_BW] T ON PN.partnumber = T.itemnumber
    AND T.TransdateTime > '2024-04-22T19:28:05.813Z'
GROUP BY 
    PN.partnumber
ORDER BY 
    numberofoccurrences DESC;
