SELECT TOP (10000) [CONTROL_ID]
      ,[CONTROL_SEQ_NO]
      ,[WHSE_ID]
      ,[BLDG_ID]
      ,[COMPANY_NO]
      ,[LOAD_NUM]
      ,[SEQ_NUM]
      ,[PREASSIGN_BOL]
      ,[CARRIER]
      ,[PRO_NUM]
      ,[ORDER_NUMBER]
      ,[PO_NO]
      ,[CARR_DELV_TYPE]
      ,[PICKUP_APPT]
      ,[DELV_APPT]
      ,[process_flag] 
  FROM [ASCTracEDI856].[dbo].[AD_204_CARR_APP_UPL_INTF] 
 --   where PO_NO = '0847017304' OR
 --     order_number = '0847017304'
 where company_no like '00-b%'
  order by  CONTROL_ID desc
  
  select count(*) FROM [ASCTracEDI856].[dbo].[AD_204_CARR_APP_UPL_INTF] 

