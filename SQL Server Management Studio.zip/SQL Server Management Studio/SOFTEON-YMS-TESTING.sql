   EXEC [ASCTracEDI856].[dbo].[API_OPENDOC_CREATE_MECH]
    @refNumber = '4506323245',
    @status = 'Scheduled',
    @action = 'create',
    @Scheduled = '2024-04-03T15:30:00.000Z',
    @start = '2024-04-03T21:00:00.000Z',
    @end = '2024-04-03T21:30:00.000Z',
    @userId = '46663073-60fd-49f2-8513-8fc6e78a0557',
    @orgID = '0c6e45ce-fbeb-47d2-85d8-660a5a4cc446',
    @loadTypeId = '86885f54-a005-4b01-bcbf-f7d880d57a5b',
    @dockId = '73638e80-ce17-4cf5-a7ae-ab30a4cdc131',
    @Tags = '[]',
    @createdBy = '46663073-60fd-49f2-8513-8fc6e78a0557',
    @lastChangedby = '46663073-60fd-49f2-8513-8fc6e78a0557',
    @DoorNumber = '', -- Extracted from JSON
    @SealNumber = '',
    @DriverName = '',
    @DriverPhone = '',
    @TrailerNumber = ''


	warehouse 5dcc6a47-890f-40b9-9acd-ce07999ae589
	user 46663073-60fd-49f2-8513-8fc6e78a0557
	dock 73638e80-ce17-4cf5-a7ae-ab30a4cdc131
	loadtype 86885f54-a005-4b01-bcbf-f7d880d57a5b

	EXEC  [ASCTracEDI856].[dbo].[API_ODYMS_MECHANICSBURG_UPDATE_UAT]
	@refNumber = '2094525675',
	@status = 'Arrived',
    @action = 'update',
    @Scheduled = '2023-12-28T15:00:00.000Z',
    @start = '2024-01-25T16:00:00.000Z',
    @end = 'PROD-UPDATE-SQLTEST',
	@userId = '94df3fdc-7e94-418c-a886-8a473f3354db', --kevint@mizner.com
	@orgID = '7eb99f17-7482-4fe8-955e-ddad36b7a9f3',
    @loadTypeId = '5f002494-4cbd-4e84-ab88-cda10621c395', --82ATGMI
 	@dockId = '3ba32754-3c37-41c5-99c2-3e5e523d4866',
    @Tags = '',
    @createdBy = '46663073-60fd-49f2-8513-8fc6e78a0557',
    @lastChangedby = '46663073-60fd-49f2-8513-8fc6e78a0557',
	--@DoorNumber = '17-DR-13',
	@DoorNumber = '', -- If source is carrier then door will be unknown.
	@SealNumber = 'test',
	@DriverName = 'Mr. Test',
	@DriverPhone = '+1 954-914-9183',
	@TrailerNumber = '1231234',
	@ConfirmationNumber = '222',
	@refNumber2 = '',
	@Arrived = '2024-01-23T17:57:00.000Z',
	@InProgress = '',
	@Completed = '',
	@Cancelled = ''

		
EXEC  [ASCTracEDI856].[dbo].[API_ODYMS_MECHANICSBURG_CANCEL_UAT]
	@refNumber = '87856027',
	@status = 'Arrived',
    @action = 'update',
    @Scheduled = '2023-12-28T15:00:00.000Z',
    @start = '2024-01-25T16:00:00.000Z',
    @end = 'PROD-UPDATE-SQLTEST',
	@userId = '94df3fdc-7e94-418c-a886-8a473f3354db', --kevint@mizner.com
	@orgID = '7eb99f17-7482-4fe8-955e-ddad36b7a9f3',
    @loadTypeId = '5f002494-4cbd-4e84-ab88-cda10621c395', --82ATGMI
 	@dockId = '3ba32754-3c37-41c5-99c2-3e5e523d4866',
    @Tags = '',
    @createdBy = '46663073-60fd-49f2-8513-8fc6e78a0557',
    @lastChangedby = '46663073-60fd-49f2-8513-8fc6e78a0557',
	--@DoorNumber = '17-DR-13',
	@DoorNumber = '', -- If source is carrier then door will be unknown.
	@SealNumber = 'test',
	@DriverName = 'Mr. Test',
	@DriverPhone = '+1 954-914-9183',
	@TrailerNumber = '1231234',
	@ConfirmationNumber = '222',
	@refNumber2 = '',
	@Arrived = '2024-01-23T17:57:00.000Z',
	@InProgress = '',
	@Completed = '',
	@Cancelled = ''


