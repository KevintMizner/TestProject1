DECLARE @json NVARCHAR(MAX);
DECLARE @refNumber NVARCHAR(MAX);
SET @refNumber = '256686';
--SET @refNumber = '4506390351';

-- Temporary table to store CTE results
DECLARE @TempTable TABLE (
    part_id NVARCHAR(50),
    uom NVARCHAR(50),
    qty INT
);

-- Insert CTE results into the temporary table
INSERT INTO @TempTable (part_id, uom, qty)
SELECT sku AS 'part_id', 'pallet' AS 'uom', COUNT(sku) AS qty
FROM [ADPROD].[VENDOR_ASN_DTL] 
WHERE bldg_id = '18' 
  AND COMPANY_NO = 'SNYDERS_LANCE' 
  AND (@refNumber IS NULL OR PO_NO = @refNumber OR RECEIPT_NO = @refNumber OR SHIPMENT_REF_NO = @refNumber)
GROUP BY sku;

-- Check if the temporary table has any rows
IF EXISTS (SELECT 1 FROM @TempTable)
BEGIN
    -- Generate JSON output if there are records
    SELECT @json = '[' + STRING_AGG(
        FORMATMESSAGE('{"SKU": "%s", "uom": "%s", "qty": "%d"}', part_id, ISNULL(uom, ''), qty),
        ','
    ) WITHIN GROUP (ORDER BY part_id) + ']'
    FROM @TempTable;
END
ELSE
BEGIN
    -- Set JSON output to NULL if there are no records
    SET @json = NULL;
END

-- Return the JSON output
SELECT @json AS JsonOutput;
