BULK INSERT Nova.Appointment
FROM '\\allen-files\users\kthomas\Documents\OpenDock\DataDump\Nova-Appointment.csv'
WITH (
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    FIRSTROW = 2  -- Assumes first row is headers
);
