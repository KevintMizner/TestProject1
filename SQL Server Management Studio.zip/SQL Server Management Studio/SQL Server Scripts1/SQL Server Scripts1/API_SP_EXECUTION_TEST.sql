EXEC  [ASCTracEDI856].[dbo].[API_OPENDOC_CREATE]
   -- @refNumber = 'ZMZMNY8122',
	--@refNumber = '2094268000',
	--@refNumber = '431-938000',
	--@refNumber = 'C4190094',
	@refNumber = 'C4190035',
	@status = 'Scheduled',
    @action = 'create',
    @Scheduled = '2023-10-30T12:00:00.000Z',
    @start = '2023-11-06T18:00:00.000Z',
    @end = 'YourEnd',
    @userId = 'cf55128b-c486-4b2b-aba5-b61d94815a9d',
    @orgID = '0c6e45ce-fbeb-47d2-85d8-660a5a4cc446',
    @loadTypeId = 'b7fcfc98-115f-455c-93a0-4e3cc8de2214',
    @dockId = 'dfe73c2d-8785-4b0d-a0a0-ef4823e6c2c9',
    @Tags = '',
    @createdBy = 'f06a205b-a66a-4124-b4ca-c68937c5501d',
    @lastChangedby = 'f06a205b-a66a-4124-b4ca-c68937c5501d',
	@DoorNumber = '17-DR-13',
	@SealNumber = '35465',
	@DriverName = 'Kevin',
	@DriverPhone = '954-914-9183',
	@TrailerNumber = '3452354'
	/*	@jsonData = '' */

	

	EXEC  [ASCTracEDI856].[dbo].[API_OPENDOC_CANCEL]
    --@refNumber = 'ZMZMNY8122',
	@refNumber = '2098975335',
	--@status = '2023-10-27T22:59:00.000Z',
    --@status = 'Arrived',
    --@status = 'Iprogress',
    @status = 'cancel',
   	@action = 'update',
    @Scheduled = '2023-09-13T19:30:00.000Z',
    @start = 'YourStart',
    @end = 'YourEnd',
    @userId = 'cf55128b-c486-4b2b-aba5-b61d94815a9d',
    @orgID = '0c6e45ce-fbeb-47d2-85d8-660a5a4cc446',
    @loadTypeId = 'b7fcfc98-115f-455c-93a0-4e3cc8de2214',
    @dockId = '27af965f-e553-4819-8ae8-90cf11f50ea0',
    @Tags = '[]',
    @createdBy = 'f06a205b-a66a-4124-b4ca-c68937c5501d',
    @lastChangedby = 'f06a205b-a66a-4124-b4ca-c68937c5501d',
	@DoorNumber = '17-DR-12',
	@SealNumber = '35465',
	@DriverName = 'Kevin',
	@DriverPhone = '954-914-9183',
	@TrailerNumber = '3452354',
	@Arrived = '2023-09-13T19:30:00.000Z',
	@InProgress = '2023-09-13T19:30:00.000Z',
	@Completed =  '2023-09-13T19:30:00.000Z',
	@Cancelled =  '2023-09-13T19:30:00.000Z'
	/*	@jsonData = '' */


	GRANT EXECUTE ON [dbo].[API_OPENDOC_CREATE_UAT] TO api_interface;
	GRANT EXECUTE ON [dbo].[API_OPENDOC_CANCEL_UAT] TO api_interface;
	GRANT EXECUTE ON [dbo].[API_OPENDOC_MULTIREF_STAGE] TO api_interface;
	GRANT EXECUTE ON [dbo].[API_OPENDOC_TEST] TO api_interface;
	GRANT EXECUTE ON [dbo].[API_OPENDOC_UPDATE_UAT] TO api_interface;


	select * from ASCTrac6.[dbo].[API_OPENDOCK_LOG] order by id desc

	SELECT top 10 * from  ASCTrac6.[dbo].DOCKSCHD where  CO_ORDERNUM is not null order by SCHEDDATE desc 
	SELECT top 10 * from  ASCTrac6.[dbo].DOCKSCHD where  CO_ORDERNUM = '2098975335'

	SELECT x.* FROM ASCTracEDI856.dbo.tbl_asctohost_BW_API_945_request x

	  SELECT 
    1, 
    SOLDTOCUSTID 
  from 
    ASCTrac6.[dbo].[ORDRHDR] 
  WHERE 
    ASCTrac6.[dbo].[ORDRHDR].CUSTPONUM LIKE '%C4190094%'



	SELECT  SHIPTONAME, SHIPTOADDRESS1, SHIPTOADDRESS2, SHIPTOCITY, SHIPTOSTATE, SHIPTOZIPCODE, *
	from ASCTrac6.[dbo].[ORDRHDR] 
	WHERE ASCTrac6.[dbo].[ORDRHDR].CUSTPONUM  = 'C4190013'  OR SOLDTOCUSTID = '35A6GMI' order by SHIPTOADDRESS4 asc


	EXEC  [ASCTracEDI856].[dbo].[API_OPENDOC_UPDATE]
		@refNumber = '2098975345',
    @status = 'update',
    @action = 'create',
    @Scheduled = '2023-09-13T19:30:00.000Z',
    @start = '2023-10-27T23:59:00.000Z',
    @end = '2023-10-27T22:30:00.000Z',
    @userId = 'b3ab8f3b-b807-43b6-908e-edd587ad02a7',
    @orgID = '0c6e45ce-fbeb-47d2-85d8-660a5a4cc446',
    @loadTypeId = 'cadb9c64-3c0d-43f6-a806-cacc9c9e7559',
    @dockId = 'dfe73c2d-8785-4b0d-a0a0-ef4823e6c2c9',
    @Tags = '[]',
    @createdBy = '',
    @lastChangedby = 'b3ab8f3b-b807-43b6-908e-edd587ad02a7',
	@DoorNumber = '',
	@SealNumber = '',
	@DriverName = '',
	@DriverPhone = '',
	@TrailerNumber = '',
	@Arrived = '',
	@InProgress = '',
	@Completed =  '',
	@Cancelled =  ''


	EXEC  [ASCTracEDI856].[dbo].[API_OPENDOC_UPDATE]
    @refNumber = '2C41900073',
    @status = '',
   --@status = 'Arrived',
   -- @status = 'Iprogress',
    @action = 'update',
    @Scheduled = '2023-09-13T19:30:00.000Z',
    @start = '2023-11-02T12:59:00.000Z',
    @end = '2023-10-27T22:30:00.000Z',
    @userId = 'b3ab8f3b-b807-43b6-908e-edd587ad02a7',
    @orgID = '0c6e45ce-fbeb-47d2-85d8-660a5a4cc446',
    @loadTypeId = 'cadb9c64-3c0d-43f6-a806-cacc9c9e7559',
    @dockId = 'dfe73c2d-8785-4b0d-a0a0-ef4823e6c2c9',
    @Tags = '[]',
    @createdBy = '',
    @lastChangedby = 'b3ab8f3b-b807-43b6-908e-edd587ad02a7',
    @DoorNumber = '',
    @SealNumber = '',
    @DriverName = '',
    @DriverPhone = '',
    @TrailerNumber = '',
    @Arrived = '2023-11-02T13:05:00.000Z',
    @InProgress = '2023-11-02T13:10:00.000Z',
    @Completed = '2023-11-02T13:29:00.000Z',
    @Cancelled = ''



	
	
	EXEC  [ASCTracEDI856].[dbo].[API_OPENDOC_CREATE]
    @refNumber = 'ZMZMNY8122',
    @status = 'Scheduled',
    @action = 'create',
    @Scheduled = '2023-09-13T19:30:00.000Z',
    @start = 'YourStart',
    @end = 'YourEnd',
    @userId = 'cf55128b-c486-4b2b-aba5-b61d94815a9d',
    @orgID = '0c6e45ce-fbeb-47d2-85d8-660a5a4cc446',
    @loadTypeId = 'b7fcfc98-115f-455c-93a0-4e3cc8de2214',
    @dockId = '27af965f-e553-4819-8ae8-90cf11f50ea0',
    @Tags = '',
    @createdBy = 'f06a205b-a66a-4124-b4ca-c68937c5501d',
    @lastChangedby = 'f06a205b-a66a-4124-b4ca-c68937c5501d',
    @DoorNumber = '17-DR-12',
    @SealNumber = '35465',
    @DriverName = 'Kevin',
    @DriverPhone = '954-914-9183',
    @TrailerNumber = '3452354'


	SELECT * FROM ASCTrac6.[dbo].[ORDRHDR] WHERE CUSTPONUM LIKE  '%C419OO13%'
	
	select * from ASCTrac6.[dbo].[API_OPENDOCK_LOG] order by id desc

	select * from [ASCTracEDI856].[dbo].[n1_04_to_custid]



	-- Example of sending an email
EXEC msdb.dbo.sp_send_dbmail
    @profile_name = 'YourProfileName',
    @recipients = 'recipient@example.com',
    @subject = 'Email Subject',
    @body = 'Email Body',
    @body_format = 'HTML';  -- You can use 'TEXT' for plain text