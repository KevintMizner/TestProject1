
SELECT SHIPFROM = CASE
                      WHEN H.SOLDTOCUSTID = '75BRAWHI' THEN
                          'STOCKTON'
                      WHEN H.SOLDTOCUSTID = '79BRAWHI' THEN
                          'SEATTLE'
                      WHEN H.SOLDTOCUSTID = '87BRAWHI' THEN
                          'KALAMAZOO'
                      ELSE
                          H.COMPANYID
                  END,
       H.SOLDTOCUSTID,
       REPLACE(H.ORDERNUMBER, 'BW', '') AS ORDERNUMBER,
       H.CUSTPONUM,
       H.LINK_NUM,
       H.REQUIREDSHIPDATE,
       C.DESCRIPTION AS CARNAME,
       H.CNTR_TYPE AS TRAILER_TYPE,
       STATUS = CASE
                    WHEN H.PICKSTATUS = 'B' THEN
                        '3 - BEING PICKED'
                    WHEN H.PICKSTATUS = 'C' THEN
                        '6 - SHIPPED'
                    WHEN H.PICKSTATUS = 'G' THEN
                        '5 - READY TO SHIP'
                    WHEN H.PICKSTATUS = 'I' THEN
                        '9 - BACK ORDER'
                    WHEN H.PICKSTATUS = 'U' THEN
                        '1 - NOT STARTED'
                    WHEN H.PICKSTATUS = 'L' THEN
                        '5 - READY TO SHIP'
                    WHEN H.PICKSTATUS = 'N' THEN
                        '1 - NOT STARTED'
                    WHEN H.PICKSTATUS = 'P' THEN
                        '4 - PARTIAL PICK'
                    WHEN H.PICKSTATUS = 'S' THEN
                        '2 - SCH TO PICK'
                    WHEN H.PICKSTATUS = 'U' THEN
                        '7 - IN-PROGRESS'
                    WHEN H.PICKSTATUS = 'X' THEN
                        '8 - CANCELED'
                    ELSE
                        '9 - OTHER'
                END,
       DQ.DETAIL_ITEMID AS ITEM,
       H.SHIPTONAME,
       (H.SHIPTOCITY + ', ' + H.SHIPTOSTATE + ' ' + H.SHIPTOZIPCODE) AS CSZ,
       SUM(DQ.DETAIL_QTYORDERED) AS DETAIL_QTYORDER,
	   			   H.CUSTOM_DATA12
FROM ORDRHDR H (NOLOCK)
    JOIN
    (
        SELECT d.ORDERNUMBER,
               d.LINENUMBER,
               d.ITEMID AS DETAIL_ITEMID,
               d.ASCITEMID,

               SUM(d.QTYORDERED) AS DETAIL_QTYORDERED,
               SUM(d.QTYPICKED) AS DETAIL_QTYPICKED,
               (SUM(d.QTYORDERED) / I.CONV_FACT_12) AS ORDR_PLT,
               (SUM(d.QTYORDERED) * I.BOL_UNITWEIGHT) AS ORDR_WGT
        FROM ORDRDET d
            JOIN ITEMMSTR I
                ON I.ASCITEMID = d.ASCITEMID
        GROUP BY d.ORDERNUMBER,
                 d.LINENUMBER,
                 d.ITEMID,
                 d.ASCITEMID,
                 I.CONV_FACT_12,
                 I.BOL_UNITWEIGHT

    ) AS DQ
        ON DQ.ORDERNUMBER = H.ORDERNUMBER
    LEFT JOIN CARRIER C
        ON C.CARRIER_ID = H.CARRIER
WHERE H.SOLDTOCUSTID IN ( '79BRAWHI', '75BRAWHI', '87BRAWHI' )
      AND H.ORDERFILLED <> 'C'
GROUP BY H.SOLDTOCUSTID,
         H.CUSTOM_DATA12,
		 H.COMPANYID,
         H.ORDERNUMBER,
         H.CUSTPONUM,
         H.CARRIER,
         H.REQUIREDSHIPDATE,
         H.PICKSTATUS,
         H.SHIPTONAME,
         H.SHIPTOCITY,
         H.SHIPTOSTATE,
         H.SHIPTOZIPCODE,
         C.DESCRIPTION,
         H.CNTR_TYPE,
         H.LINK_NUM,
         DQ.DETAIL_ITEMID
ORDER BY H.SOLDTOCUSTID,
         H.SHIPTOSTATE,
         H.REQUIREDSHIPDATE,
         SUBSTRING(H.SHIPTOZIPCODE, 1, 3),
         H.ORDERNUMBER,
         DQ.DETAIL_ITEMID ASC;

