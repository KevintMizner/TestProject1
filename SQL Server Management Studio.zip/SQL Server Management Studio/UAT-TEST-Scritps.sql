EXEC  [ASCTracEDI856].[dbo].[API_OPENDOC_CREATE_UAT]
   -- @refNumber = 'ZMZMNY8122',
	--@refNumber = '2094268000',
	--@refNumber = '431-938000',
	--@refNumber = 'C4190094',
	@refNumber = 'C4190035',
	---@refNumber = 'xcvxcvzxcvzxcvzxcv',
	@status = 'Scheduled',
    @action = 'create',
    @Scheduled = '2023-10-30T07:00:00.000Z',
    @start = '2023-12-07T15:00:00.000Z',
    @end = 'YourEnd',
   --@userId = 'cf55128b-c486-4b2b-aba5-b61d94815a9d',
	@userId = 'b3ab8f3b-b807-43b6-908e-edd587ad02a7',  -- kthomas
    @orgID = '0c6e45ce-fbeb-47d2-85d8-660a5a4cc446',
	--@loadTypeId = 'b7fcfc98-115f-455c-93a0-4e3cc8de2214',  --inbound
    @loadTypeId = 'cadb9c64-3c0d-43f6-a806-cacc9c9e7559', --outbound
    @dockId = 'dfe73c2d-8785-4b0d-a0a0-ef4823e6c2c9',
    @Tags = '',
    @createdBy = 'f06a205b-a66a-4124-b4ca-c68937c5501d',
    @lastChangedby = 'f06a205b-a66a-4124-b4ca-c68937c5501d',
	@DoorNumber = '17-DR-13',
	@SealNumber = '35465',
	@DriverName = 'Kevin',
	@DriverPhone = '954-914-9183',
	@TrailerNumber = '3452354'


	@Arrived = '',
	@InProgress  = '',
	@Completed  = '',
	@Cancelled  = ''

	INSERT INTO ASCTrac6.[dbo].DOCKSCHD ([SITE_ID],[CUSTID],[CO_ORDERNUM],[PO_ORDERNUM],[LOADINGBAY],[APPOINT_DATE],[APPOINT_TTIME],[APPT_MADE_DATETIME],[APPT_MADE_USERID],SCHEDDATE)
	VALUES ('A', '35A6GMI', '2098975335', 'C4190035', '17-DR-13', '2023-12-07', '09:00:00', '', '', '2023-12-07')


SELECT * from  ASCTrac6.[dbo].DOCKSCHD where PO_ORDERNUM = 'C4190035'
SELECT @TOTAL_QTY_ORDERED = SUM(QTYORDERED) FROM ASCTrac6.[dbo].[ORDRDET] WHERE ORDERNUMBER  = '2094268000'
DECLARE @TOTAL_QTY_ORDERED INT;
SELECT @TOTAL_QTY_ORDERED = SUM(QTYORDERED) FROM ASCTrac6.[dbo].[ORDRDET] WHERE CUSTPONUM  = 'C4190035'

SELECT * FROM ASCTrac6.[dbo].[ORDRDET] WHERE CUSTPONUM  = 'C4190035'
SELECT @TOTAL_QTY_ORDERED = SUM(QTYORDERED) FROM ASCTrac6.[dbo].[ORDRDET] WHERE ORDERNUMBER  = @refNumber


SELECT * FROM ASCTrac6.[dbo].[ORDRDET] WHERE ORDERNUMBER  = '2098975335'
SELECT * FROM ASCTrac6.[dbo].[ORDRDET] WHERE CUSTPONUM  = 'C4190035'

SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'ORDRHDR'
ORDER BY COLUMN_NAME;
	
	SELECT REQUIREDSHIPDATE, * FROM ASCTrac6.[dbo].[ORDRHDR] where ORDERNUMBER  = '2098975335'


	'EXEC  [ASCTracEDI856].[dbo].[API_OPENDOC_CANCEL_UAT]
   -- @refNumber = 'ZMZMNY8122',
	--@refNumber = '2094268000',
	--@refNumber = '431-938000',
	--@refNumber = 'C4190094',
	@refNumber = 'C4190035',
	@status = 'Scheduled',
    @action = 'create',
    @Scheduled = '2023-10-30T07:00:00.000Z',
    @start = '2023-12-13T15:00:00.000Z',
    @end = 'YourEnd',
   --@userId = 'cf55128b-c486-4b2b-aba5-b61d94815a9d',
	@userId = 'b3ab8f3b-b807-43b6-908e-edd587ad02a7',  -- kthomas
    @orgID = '0c6e45ce-fbeb-47d2-85d8-660a5a4cc446',
	--@loadTypeId = 'b7fcfc98-115f-455c-93a0-4e3cc8de2214',  --inbound
    @loadTypeId = 'cadb9c64-3c0d-43f6-a806-cacc9c9e7559', --outbound
    @dockId = 'dfe73c2d-8785-4b0d-a0a0-ef4823e6c2c9',
    @Tags = '',
    @createdBy = 'f06a205b-a66a-4124-b4ca-c68937c5501d',
    @lastChangedby = 'f06a205b-a66a-4124-b4ca-c68937c5501d',
	@DoorNumber = '17-DR-13',
	@SealNumber = '35465',
	@DriverName = 'Kevin',
	@DriverPhone = '954-914-9183',
	@TrailerNumber = '3452354'


	@Arrived = '',
	@InProgress  = '',
	@Completed  = '',
	@Cancelled  = ''

