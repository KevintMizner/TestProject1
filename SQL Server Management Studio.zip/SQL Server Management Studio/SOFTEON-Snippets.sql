select top 10 ord_no , BOL_NO , PO_NO ,CARR_CD,REF_ORD_NO, MASTER_ORD_NO, BATCH_REFERENCE_NO, COMPANY_NO, CUST_GRP2, BLDG_ID, CUST_ID from [ADPROD].[ORDER_HEADER] order by internalcreatedate desc

select top 500 ord_no , * from [ADPROD].[ORDER_DETAIL] where ord_no = 256686 order by internalcreatedate desc

SELECT TOP 50 CLOSE_TSTAMP,MODIFY_TSTAMP, ord_no, BOL_NO, PO_NO, PARENT_ORD_NO, SHIPMENT_REF_NO,  REF_ORD_NO, ORD_GROUP_NO,ORD_SOURCE CUST_NAME, PICKUP_DATE, CARR_CD, BATCH_REFERENCE_NO, BLDG_ID, CUST_ID,
TOT_FULL_CASES, TOT_FULL_PALLETS, TOT_LOOSE_CASE_UNITS, TOT_LOOSE_CASES, TOT_LOOSE_UNITS,
TOT_ORD_PALLET_CUBAGE, TOTAL_QTY, WHSE_ID, WORK_ORDER_STATUS, DELIVERY_START_DATE,
DELIVERY_END_DATE, DONOT_SHIP_BEFORE_DATE, DONOT_SHIP_AFTER_DATE, ORD_DATE, ORD_AMT,
ORD_GROUP_NO, ORD_MEMO, ORD_STATUS, PROMISED_DATE, SHIPMENT_REF, EST_NUMBER_OF_CARTONS,
EST_SHIP_ORD_CUBAGE, EST_SHIP_ORD_WT, SEQ_ID,
REF_ID9,REF_TYPE9,REF_TYPE10,REF_TYPE11,REF_TYPE12,REF_TYPE13,REF_CD2
FROM [ADPROD].[ORDER_HEADER]
where ord_no like '%256686%'
order by CLOSE_TSTAMP asc



Select top 10 * from AD_940_ORDER_DETAIL_INTF where ORDERNUMBER = 'PRIMETEST'
Select top 10 * from AD_940_ORDER_HEADER_INTF where CUST_PO_NUM like 'PRIME%'
Select * from AD_856_ASN_HDR_UPL_INTF where PONUMBER like 'PRIME%'

select top 10 * from [ADPROD].[VENDOR_ASN_HDR] where bldg_id = '6'  order by InternalModifiedDate desc shipment_ref_no like '%256686%'


SELECT TOP 50 * from [ADPROD].[PO_HEADER] where PO_NO like '%256686%'

select top 10 * from [ADPROD].[PCN_HDR]

ORDER BY internalcreatedate DESC

select PO_NO , ORDER_NO, BOL_NUMBER, DO_NOT_SHIP_BEFORE_DATE,CUST_SHIPTO_PO_NUM, DO_NOT_SHIP_AFTER_DATE, DISTRIBUTION_CENTER, BUSINESS_UNIT, SHIP_TO_ADDRESS_LINE1,SHIP_TO_ADDRESS_LINE2, SHIP_TO_ADDRESS_LINE3, SHIP_TO_ADDRESS_LINE4, SHIP_TO_ADDRESS_LINE5, SHIP_TO_ADDRESS_NAME,SHIP_TO_ATTN_LINE, SHIP_TO_CITY, SHIP_TO_STATE, SHIP_TO_ZIP,
* FROM [ADPROD].[I_ORDER_HDR_UPL_INTF] WHERE PO_NO = '256686' OR PO_NO = '256687' OR PO_NO = '256689'
select PO_NO , * FROM [ADPROD].[I_ORDER_DTL_UPL_INTF] WHERE PO_NO = '256686' -- OR PO_NO = '256687' OR PO_NO = '256689'

select PO_NO , ORDER_NO, BOL_NUMBER, DO_NOT_SHIP_BEFORE_DATE,CUST_SHIPTO_PO_NUM, DO_NOT_SHIP_AFTER_DATE, DISTRIBUTION_CENTER, BUSINESS_UNIT, SHIP_TO_ADDRESS_LINE1,SHIP_TO_ADDRESS_LINE2, SHIP_TO_ADDRESS_LINE3, SHIP_TO_ADDRESS_LINE4, SHIP_TO_ADDRESS_LINE5, SHIP_TO_ADDRESS_NAME,SHIP_TO_ATTN_LINE, SHIP_TO_CITY, SHIP_TO_STATE, SHIP_TO_ZIP,
* FROM [ADPROD].[I_ORDER_HDR_UPL_INTF] WHERE PO_NO = '256686' OR PO_NO = '256687' OR PO_NO = '256689'

Select * FROM [ADPROD].[ORDER_GROUP_HDR] WHERE PO_NO = '256686' 

Select top 10 * from [ADPROD].[SKU_PROFILE] where SKU = 'FCASC0040BSY01'

TRUCK_STOP_NO
TRUCK_REF_NO



select top 200 CLOSE_TSTAMP,*
FROM [ADPROD].[ORDER_HEADER] 




select top 200 *
FROM [ADPROD].[ORDER_HEADER] 
where bldg_id ='18' and company_no Like 'sny%' 
ORDER BY internalcreatedate DESC


TOT_FULL_CASES
TOT_FULL_PALLETS
TOT_LOOSE_CASE_UNITS
TOT_LOOSE_CASES
TOT_LOOSE_UNITS
TOT_ORD_PALLET_CUBAGE
TOTAL_QTY
WHSE_ID
WORK_ORDER_STATUS
DELIVERY_START_DATE
DELIVERY_END_DATE
DONOT_SHIP_BEFORE_DATE
DONOT_SHIP_AFTER_DATE
ORD_DATE
ORD_AMT
ORD_GROUP_NO
ORD_MEMO
ORD_STATUS
PROMISED_DATE
SHIPMENT_REF
EST_NUMBER_OF_CARTONS
EST_SHIP_ORD_CUBAGE
EST_SHIP_ORD_WT

cWHSE_ID
cEST_NUMBER_OF_CARTONS
cEST_SHIP_ORD_CUBAGE
cEST_SHIP_ORD_WT
cMASTER_ORD_NO
cREF_ORD_NO
cSEQ_ID
cSHIPMENT_REF
cSHIPMENT_REF_NO
cSTD_SKU_AMT
cSTD_SKU_QTY
cSTD_SKU_LINES
cSTOP1_ADDR_ID
cSTOP2_ADDR_ID
cSTORAGE_LOC_ID
cTOT_FULL_PALLETS
cTOT_FULL_CASES
cTOT_LOOSE_CASE_UNITS
cTOT_LOOSE_CASES
cTOT_LOOSE_UNITS
cTOT_ORD_PALLET_CUBAGE
cTOTAL_QTY





select top 10 * from [ADPROD].[ORDER_DETAIL] order by 

[ADPROD].[PO_HEADER]

SELECT TOP 10 *
FROM [ADPROD].[ORDER_HEADER] OH
INNER JOIN [ADPROD].[ORDER_DETAIL] OD ON OH.ord_no = OD.ord_no
ORDER BY OH.internalcreatedate DESC;

CLOSE_TSTAMP

SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'ORDER_HEADER'
AND COLUMN_NAME LIKE '%close%' 
ORDER BY COLUMN_NAME;

SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'ORDER_DETAIL'
ORDER BY COLUMN_NAME;

SELECT DISTINCT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'ORDER_HEADER'  -- Adjust table name as needed
AND COLUMN_NAME LIKE '%cus%'      -- Filter for columns containing 'code'
ORDER BY COLUMN_NAME;

SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'ORDER_DETAIL'
--AND (COLUMN_NAME LIKE '%code%'    -- Filter for columns containing 'code' 
--OR  COLUMN_NAME LIKE '%code%' )   -- Filter for columns containing 'code'
ORDER BY COLUMN_NAME;

select top 100 * from [ADPROD].[PO_HEADER] where bldg_id ='18' and company_no Like '%sny%'   and PO_NO =  '4506368328' order by  PO_DATE desc  -- 

select top 100 * from [ADPROD].[PO_HEADER] company_no where  PO_NO =  '4506368328' order by  PO_DATE desc  -- 


--select top 10 * from [ADPROD].[PO_HEADER] where bldg_id ='18' and company_no Like '%sny%'  and PO_CREATION_TYPE IN ('U', 'S')  order by internalcreatedate desc, PO_DATE desc  -- 

select top 50 * from  [ADPROD].[RCV_PO_DTL] where bldg_ID  = '18' and PO_NO = '4506360996'



select top 10 * from [ADPROD].[RCV_PO_ASN_DTL] where PO_NO = '4506368328'

select top 50 SKU, PALLET_ID from  [ADPROD].[RCV_PO_DTL] where PO_NO = '4506368328'

select top 50 * from [ADPROD].[VENDOR_ASN_HDR] where REF_FIELD8 = '4506368328'  
select sku from [ADPROD].[VENDOR_ASN_DTL] where PO_NO = '4506368328'


SELECT sku, CASE WHEN UNITS_PER_CASE = 1 THEN 'CA' ELSE 'EA' END AS UOM,
count(*) FROM [ADPRODINTF].[AD_856_ASN_DTL_UPL_INTF] a
JOIN adprod.SKU_PROFILE sp 
ON a.ITEMID =sp.SKU 
WHERE VMI_CUSTID = 'SNYDERS_LANCE' and PONUMBER = '4506368328' 
GROUP BY sku,CASE WHEN UNITS_PER_CASE = 1 THEN 'CA' ELSE 'EA' END  


select top 10 * FROM [ADPRODINTF].[AD_856_ASN_DTL_UPL_INTF] where ponumber = '256686'
select top 10 * from [ADPROD].[ORDER_HEADER] where ord_no = '256686'
select * from [ADPROD].[PO_HEADER] WHERE PO_NO = '256686'
select * from [ADPROD].[RCV_PO_ASN_DTL] WHERE PO_NO = '256686' 
select top 10 * from [ADPROD].[RCV_DTL] where RECEIPT_NO = '256686'



DECLARE @json NVARCHAR(MAX);
DECLARE @refNumber as NVARCHAR(MAX);
SET @refNumber = '4506390351' ;

select * from [ADPROD].[PO_HEADER] WHERE PO_NO = @refNumber
select * from [ADPROD].[RCV_PO_ASN_DTL] WHERE PO_NO = @refNumber 
select top 10 * from [ADPROD].[RCV_DTL] where RECEIPT_NO = @refNumber

WITH CTE AS (
SELECT sku AS 'part_id', 'pallet' AS 'uom', 
       COUNT(sku) AS qty
FROM  [ADPROD].[VENDOR_ASN_DTL]
WHERE PO_NO = @refNumber
GROUP BY sku
)
SELECT @json = '[' + STRING_AGG(
    FORMATMESSAGE('{"SKU": "%s", "uom": "%s", "qty": "%d"}', part_id, ISNULL(uom, ''), qty),
    ','
) WITHIN GROUP (ORDER BY part_id)
+ ']' 
FROM CTE
SELECT *
FROM adprod.PO_DETAIL pd
WHERE po_no = '4506380140'
   OR po_no = '4506372928'
   OR po_no = '4506368578'
   OR po_no = '4506380139'
   OR po_no = '4506380304'
   OR po_no = '4506376548'
   OR po_no = '4506380137'
   OR po_no = '4506381686'
   OR po_no = '4506376549'
   OR po_no = '4506380136'
   OR po_no = '4506369499'
   OR po_no = '4506362628'
   OR po_no = '4506386265'
   OR po_no = '4506380672'
   OR po_no = '4506377377'
   OR po_no = '4506386270'
   OR po_no = '4506383654'
   OR po_no = '4506381687'
   OR po_no = '4506386271'
   OR po_no = '4506380670'
   OR po_no = '4506381688'
   OR po_no = '4506386272'
   OR po_no = '4506380672'
   OR po_no = '4506379115'
   OR po_no = '4506380128'
   OR po_no = '4506372880'
   OR po_no = '4506349375';

SELECT @json AS JsonOutput;
 --bldg_ID = '18' 

--

--DECLARE @json NVARCHAR(MAX);
WITH CTE AS (
SELECT sku AS 'part_id', 'pallet' AS 'uom', 
       COUNT(sku) AS qty
FROM  [ADPROD].[RCV_PO_DTL] 
WHERE PO_NO = @refNumber
GROUP BY sku
)
SELECT @json = '[' + STRING_AGG(
    FORMATMESSAGE('{"SKU": "%s", "uom": "%s", "qty": "%d"}', part_id, ISNULL(uom, ''), qty),
    ','
) WITHIN GROUP (ORDER BY part_id)
+ ']' 
FROM CTE;
SELECT @json AS JsonOutput;

--DECLARE @json NVARCHAR(MAX);
WITH CTE AS (
SELECT sku AS 'part_id', 'pallet' AS 'uom', 
       COUNT(sku) AS qty
FROM  [ADPROD].[RCV_PO_ASN_DTL] 
WHERE PO_NO = @refNumber
GROUP BY sku
)
SELECT @json = '[' + STRING_AGG(
    FORMATMESSAGE('{"SKU": "%s", "uom": "%s", "qty": "%d"}', part_id, ISNULL(uom, ''), qty),
    ','
) WITHIN GROUP (ORDER BY part_id)
+ ']' 
FROM CTE;
SELECT @json AS JsonOutput;

--

SELECT sku AS 'part_id', 'pallet' AS 'uom', 
       COUNT(sku) AS qty
FROM  [ADPROD].[RCV_PO_DTL] 

select *  FROM  [ADPROD].[RCV_PO_ASN_DTL] 
WHERE  PO_NO = '4506380304'

select * from [ADPROD].[RCV_HDR] WHERE  PO_NO = '4506380304'

select *  FROM  [ADPROD].[RCV_PO_ASN_DTL] 
WHERE  PO_NO = '4506380304'

DECLARE @json NVARCHAR(MAX);

WITH CTE AS (
    SELECT part_id, uom, qty,
           COUNT(*) OVER (PARTITION BY part_id) AS ttlpallets
    FROM YourTableName
    -- Add any necessary WHERE or ORDER BY clauses here
)
SELECT @json = '[' + STRING_AGG(
    FORMATMESSAGE('{"part_id": "%s", "uom": "%s", "qty": "%s", "ttlpallets": %d}', part_id, ISNULL(uom, ''), qty, ttlpallets),
    ','
) WITHIN GROUP (ORDER BY part_id)
+ ']' 
FROM CTE;

SELECT @json AS JsonOutput;

SELECT  ORDERNUMBER,PRODUCT_CODE , TRANS_cd, sum(QUANTITY) FROM 
adprodintf.AD_947_INV_ADJ_INTF x
WHERE ORDERNUMBER ='4506365925'
GROUP BY ORDERNUMBER,PRODUCT_CODE , TRANS_cd
